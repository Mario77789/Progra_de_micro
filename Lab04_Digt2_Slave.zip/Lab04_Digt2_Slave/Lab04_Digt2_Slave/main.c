/*
 * Lab04_Digt2_Slave.c
 *
 * Created: 1/08/2025 08:53:26
 * Author : mario
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "I2C/I2C.h"

#define BTN_INC PB0  // D8
#define BTN_DEC PB1  // D9

volatile uint8_t contador = 0;

void actualizarLEDs(uint8_t valor) {
	PORTD = (PORTD & 0xF0) | (valor & 0x0F); // PD0�PD3
}

void setup(void) {
	// LEDs en PD0�PD3 como salida
	DDRD |= 0x0F;

	// Botones PB0 y PB1 como entrada con pull-up
	DDRB &= ~((1 << BTN_INC) | (1 << BTN_DEC));
	PORTB |= (1 << BTN_INC) | (1 << BTN_DEC);

	// Habilita interrupciones por cambio de pin (PCINT0 y PCINT1)
	PCICR |= (1 << PCIE0);                         // Grupo PCINT[7:0]
	PCMSK0 |= (1 << PCINT0) | (1 << PCINT1);       // Habilita PB0 y PB1

	// Inicializar I�C como esclavo
	I2C_SlaveInit(0x20);

	sei(); // Habilitar interrupciones globales
}

// ISR para botones (cambio de pin)
ISR(PCINT0_vect) {
	static uint8_t prevState = 0xFF;
	uint8_t actual = PINB & ((1 << BTN_INC) | (1 << BTN_DEC));
	uint8_t cambio = prevState ^ actual;

	if (cambio & (1 << BTN_INC)) {
		if (!(actual & (1 << BTN_INC)) && contador < 15)
		contador++;
	}
	if (cambio & (1 << BTN_DEC)) {
		if (!(actual & (1 << BTN_DEC)) && contador > 0)
		contador--;
	}

	prevState = actual;
	actualizarLEDs(contador);  // ?? MOSTRAR cambio inmediatamente
}

int main(void) {
	setup();

	while (1) {
		// Espera solicitud del maestro
		while (!(TWCR & (1 << TWINT)));
		if ((TWSR & 0xF8) == 0xA8) { // SLA+R recibido
			I2C_SlaveTransmit(contador);
		}
	}
}

