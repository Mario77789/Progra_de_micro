/*  
 * Prelab5.c  
 *  
 * Created: 07/04/2025  
 * Author: Mario  
 * Description: Control de servos y led  
 */  

#include "Servo/Servo.h"  

int main(void) {  
    // Inicializar todo el sistema  
    controller_init();  
    
    // Variables para almacenar valores filtrados  
    static uint16_t ultimo_led = 0;  
    static uint16_t ultimo_servo1 = 0;  
    static uint16_t ultimo_servo2 = 0;  
    
    while (1) {  
        // LED - ADC5  
        uint16_t adc_val = adc_read(ADC_LED_CHANNEL);  
        ultimo_led = adc_filter(ADC_LED_CHANNEL, adc_val);  
        set_led_brightness(ultimo_led >> 2); // Convertir a 8-bit  
        
        // Servo 1 - ADC6  
        uint16_t adc6_val = adc_read(ADC_SERVO1_CHANNEL);  
        ultimo_servo1 = adc_filter(ADC_SERVO1_CHANNEL, adc6_val);  
        set_servo1_position(adc_to_servo(ultimo_servo1));  
        
        // Servo 2 - ADC7  
        uint16_t adc7_val = adc_read(ADC_SERVO2_CHANNEL);  
        ultimo_servo2 = adc_filter(ADC_SERVO2_CHANNEL, adc7_val);  
        set_servo2_position(adc_to_servo(ultimo_servo2));  
        
        _delay_ms(20); // Tiempo entre lecturas  
    }  
    
    return 0; // Nunca llegar� aqu�  
}  