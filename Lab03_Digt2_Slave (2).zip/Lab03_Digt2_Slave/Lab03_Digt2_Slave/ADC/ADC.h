/*
 * ADC.h
 *
 * Created: 25/07/2025 11:15:13
 *  Author: mario
 */ 


#ifndef ADC_H_
#define ADC_H_

void ADC_Init(void);
uint16_t ADC_Read(uint8_t canal);

#endif
